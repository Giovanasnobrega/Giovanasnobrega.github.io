let idade = "10";

if (idade === 10) {
  console.log("Entrou na condição");
} else {
  console.log("Não entrou na condição");
}

// let nome = "Germana";

{
  let nome = "Talita";
  console.log(nome);
}

// console.log(nome);

//console.log(nome)
