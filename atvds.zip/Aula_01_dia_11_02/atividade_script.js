let $nome = "Germana";
console.log("Meu nome é" + $nome);

let _idade = 15;
console.log("Eu tenho " + _idade + " anos. ");

let $escola = "EEEP Lucia Helena Viana Ribeiro";
console.log("Estudo na escola" + $escola);

let $turma = "2° ano de Informática";
console.log("Eu faço o" + $turma);
